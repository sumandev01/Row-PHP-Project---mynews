<?php
//connection
include_once ("lib/admin-function.php");

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $link = $_POST['link'];

    $ulink_sql = "INSERT INTO usefull_link (title, link) VALUES ('$title','$link')";

    if ($conn-> query($ulink_sql)) {
        header("Location: footer.php?addstatus=success");
    }else {
        die($conn-> error);
    }
}


get_header();
get_sidebar();
?>
    <div class="card mb-4">
        <div class="card-body">
          <h3 class="mb-4">Insert Usefull Link</h3>
          <div class="row">
            <div class="col-lg-4">
             <!-- Category Insert Form Start -->
             <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="">
              <div class="mb-3">
               <label for="title" class="form-label">Title</label>
               <input type="text" class="form-control" id="title" name="title" required>
               </div>
               <div class="mb-3">
                   <label for="link" class="form-label">Link</label>
                   <input type="text" class="form-control" id="link" name="link" required>
               </div>
           <button class="btn btn-dark" type="submit" name="submit">Submit</button>
           <button class="btn btn-danger" type="reset">Reset</button>
       </form>
   </div>
</div>
</div>
</div>
</div>
</main>
<?php get_footer(); ?>