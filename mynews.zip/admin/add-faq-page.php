<?php
//connection
    include_once ("lib/admin-function.php");

   if (isset($_POST['update'])) {
       $faq = $_POST['faq'];
       $ans = htmlspecialchars($_POST['ans']);

       $faq_sql = "INSERT INTO faq(faq, ans) VALUES ('$faq','$ans')";

       if ($conn-> query($faq_sql)) {
           header("Location: faq-page.php?status=success");
       }else {
        die($conn-> error);
       }
   }

    get_header();
    get_sidebar();

?>      <div class="card mb-4">
            <div class="card-header">
                <h3 class="fw-bold">Add FAQ</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <div class="mb-3">
                        <label for="faq" class="form-label fw-bold">FAQ</label>
                        <input type="text" class="form-control" id="faq" name="faq" required>
                    </div>
                    <div class="mb-3">
                        <label for="ans" class="form-label fw-bold">Ans</label>
                        <textarea name="ans" id="ans" class="form-control" rows="7"></textarea>
                    </div>
                    <button type="submit" name="update" type="button" class="btn btn-dark">Add Now</button>
                    <button type="reset" name="update" type="button" class="btn btn-danger">Reset</button>
                </form>
            </div>
        </div>
    </div>
   </main>
<?php get_footer(); ?>