<?php
//connection
    include_once ("lib/admin-function.php");

   if (isset($_POST['update'])) {
       $title = $_POST['title'];
       $description = htmlspecialchars($_POST['description']);

       $about_sql = "UPDATE about set title = '$title', description = '$description' ";

       if ($conn-> query($about_sql)) {
           header("Location: about-page.php?status=success");
       }else {
        die($conn-> error);
       }
   }

    //about table query
    $about_sql = "SELECT * FROM about";
    $conn_about = $conn-> query($about_sql);
    if ($conn_about-> num_rows > 0) {
        $about_final = $conn_about-> fetch_assoc();
    }

    get_header();
    get_sidebar();

?>      <div class="card mb-4">
            <div class="card-header">
                <h3 class="fw-bold">Edit about page</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label fw-bold">Title</label>
                        <input value="<?= $about_final['title']; ?>" type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label fw-bold">Description</label>
                        <textarea name="description" id="description" class="form-control" rows="7"><?= $about_final['description']; ?></textarea>
                    </div>
                    <button type="submit" name="update" type="button" class="btn btn-dark">Update Now</button>
                </form>
            </div>
        </div>
    </div>
   </main>
<?php get_footer(); ?>