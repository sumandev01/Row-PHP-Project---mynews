<?php
    //connection
    include_once ("lib/admin-function.php");

    $message = "";

    // contact table query
    $contact_sql = "SELECT * FROM contact";
    $conn_contact = $conn-> query($contact_sql);

    if ($conn_contact-> num_rows > 0) {
        $contact_result = $conn_contact-> fetch_assoc();
    }

    // Contact form table query
    $cform_sql = "SELECT * FROM contact_form ORDER BY id DESC";
    $cform_check = $conn-> query($cform_sql);

    get_header();
    get_sidebar();

?>  <div class="update-message mb-4">
        <p class="text-success"><?= $message; ?></p>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="fw-bold">Contact page info</h3>
        </div>
        <div class="card-body">
            <h5 class="mt-4 d-block fw-bold">Title:</h5><hr>
            <h1><?= $contact_result['title']; ?></h1>
            <h5 class="mt-4 d-block fw-bold">Description:</h5><hr>
            <p><?= nl2br(html_entity_decode($contact_result['description']));  ?></p>
            <a href="edit-contact-page.php">Edit</a>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3 class="fw-bold">Contact me</h3>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="w-100">
                <thead class="table-light">
                    <tr>
                        <th>Sl</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $count = 0;
                        if ($cform_check-> num_rows > 0) {
                            while($cform_result = $cform_check-> fetch_assoc()) {
                                $final = $cform_result;
                                $count++;
                            ?>
                        <tr>
                            <td><?= $count; ?></td>
                            <td><?= $final['name']; ?></td>
                            <td><?= $final['email']; ?></td>
                            <td><?= htmlspecialchars($final['message']); ?></td>
                        </tr>
                    <?php } }else { ?>
                        <tr>
                            <td class="fw-bold" colspan="4">Data not found</td>
                        </tr>
                        <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    </div>
   </main>
<?php get_footer(); ?>