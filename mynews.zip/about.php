<?php 
    include_once("function/function.php");

    // about table query
    $about_sql = "SELECT * FROM about";
    $conn_about = $conn-> query($about_sql);

    if ($conn_about-> num_rows > 0) {
        $final = $conn_about-> fetch_assoc();
    }

    get_header();
?>
    <!-- About Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="fw-bold mb-4 text-center"><?= $final['title'] ?></h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <p><?= nl2br(htmlspecialchars_decode($final['description'])); ?></p>
                </div>
            </div>
        </div>
    </section>
<?php 
    get_footer();

?>