<?php 
    include "db.php";
    $success_message = "";

    // Footer table query
    $f1_sql = "SELECT * FROM footer_1";
    $f1_check = $conn-> query($f1_sql);
    if ($f1_check-> num_rows > 0) {
        $f1_result = $f1_check-> fetch_assoc();
    }

    // Usefull link table query
    $usf_sql = "SELECT * FROM usefull_link";
    $usf_check = $conn-> query($usf_sql);

    // Submition form table query
    if (isset($_POST['subscribe'])) {
        $email = $_POST['email'];

        $sf_sql = "INSERT INTO subscription_form(email) VALUES ('$email')";

        if ($conn-> query($sf_sql)) {
            $success_message = "Thank you for subscribing!";
            unset($_POST['email']);
        }else {
            die($conn-> error);
        }
    }

?>
<?php if (!empty($success_message)) : ?>
<div id="subscribeSuccess" class="alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-4 shadow" role="alert" style="z-index: 9999; min-width: 300px;">
    ✅ <?= htmlspecialchars($success_message); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

    <!-- footer start -->
    <footer>
        <div class="container">
            <div class="row">
            <div class="col-lg-3">
                <div class="f_text">
                    <h2><?= $f1_result['web_title'] ?></h2>
                    <p><?= nl2br(htmlspecialchars_decode($f1_result['web_des'])); ?></p>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="f_text">
                    <h2><?= $f1_result['usefull_title'] ?></h2>
                    <ul class="list-unstyled">
                        <?php 
                            if ($usf_check-> num_rows > 0) {
                                while($usf_result = $usf_check-> fetch_assoc()){ ?>
                                    <li><a href="<?= $usf_result['link']; ?>" class="text-dark"><?= $usf_result['title']; ?></a></li>
                        <?php        }
                            }
                        ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="f_text">
                    <h2><?= $f1_result['contact_title']; ?></h2>
                    <p><?= nl2br(htmlspecialchars_decode($f1_result['contact_info'])); ?></p>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="f_text">
                    <h2><?= $f1_result['sub_title']; ?></h2>
                    <form action="<?= $_SERVER['REQUEST_URI']; ?>" method="post">
                        <div class="mb-3">
                            <label for="email" class="form-label"><?= $f1_result['sub_des']; ?></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php if (empty($success_message) && isset($_POST['email'])) echo htmlspecialchars($_POST['email']); ?>" >
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-dark w-100" name="subscribe">Subscribe here</button>
                        </div>
                    </form>
                </div>
            </div>
            </div>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <p class="text-center m-0 copy"><?= str_replace('%YEAR%', date('Y'), $f1_result['footer_bottom']); ?></p>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer end -->
    <!-- JS links -->
    <script src="vendor/js/popper.min.js"></script>
    <script src="vendor/js/bootstrap.min.js"></script>
    <script src="vendor/js/script.js"></script>
    <script>
</script>

</body>
</html>