<?php
//connection
include_once ("lib/admin-function.php");

$sec_message = "";
$banner_message = "";

$banner_sql = "SELECT * FROM banner";
$conn_banner = $conn-> query($banner_sql);
if ($conn_banner-> num_rows > 0) {
    $banner_result = $conn_banner-> fetch_assoc();
}

$section1_sql = "SELECT * FROM home_section1";
$conn_section1 = $conn-> query($section1_sql);
if ($conn_section1-> num_rows > 0) {
    $section1_result = $conn_section1-> fetch_assoc();
}
$section2_sql = "SELECT * FROM home_section2";
$conn_section2 = $conn-> query($section2_sql);
if ($conn_section2-> num_rows > 0) {
    $section2_result = $conn_section2-> fetch_assoc();
}

$section3_sql = "SELECT * FROM home_section3";
$conn_section3 = $conn-> query($section3_sql);
if ($conn_section3-> num_rows > 0) {
    $section3_result = $conn_section3-> fetch_assoc();
}

$section4_sql = "SELECT * FROM home_section4";
$conn_section4 = $conn-> query($section4_sql);
if ($conn_section4-> num_rows > 0) {
    $section4_result = $conn_section4-> fetch_assoc();
}

// Section update success message
if (isset($_SESSION['success_message'])) {
    $section = $_SESSION['success_message'];
    unset($_SESSION['success_message']); // 1 বার দেখানোর পর মুছে ফেলবে
    
    $section_name = '';

    // Section name switch/case
    switch ($section) {
        case 'home_section1':
            $section_name = 'Section 1';
            break;
        case 'home_section2':
            $section_name = 'Section 2';
            break;
        case 'home_section3':
            $section_name = 'Section 3';
            break;
        case 'home_section4':
            $section_name = 'Section 4';
            break;
        default:
            $section_name = '';
            break;
    }

    if (!empty($section_name)) {
        $sec_message = '<div class="alert alert-success"> <span class="fw-bold textEuppercase"> '. $section_name .'.</span> Data updated successfully!</div>';
    } else {
        $sec_message = "Section updated successfully!";
    };
}
    
// Banner update success message
if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $banner_message = '<div class="alert alert-success">Banner updated successfully!</div>';
}


get_header();
get_sidebar();

?>  <div class="update-message mb-4">
        <p class="text-success"><?= $sec_message; ?></p>
        <p class="text-success"><?= $banner_message; ?></p>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="fw-bold">Home page info</h3>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Banner Section</h4>
        </div>
      <div class="card-body">
        <i class="<?= $banner_result['banner_icon']; ?>" ></i>
        <h5><?= $banner_result['banner_title']; ?></h5>
        <p><?= $banner_result['banner_des']; ?></p>
        <p><?= $banner_result['banner_link']; ?></p>
        <a href="banner.php">Edit</a>
      </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Section 1</h4>
        </div>
      <div class="card-body">
        <h5><?= $section1_result['title']; ?></h5>
        <p><?= $section1_result['description']; ?></p>
        <a href="edit-section.php?s1_id=<?= $section1_result['id']; ?>">Edit</a>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Section 2</h4>
        </div>
      <div class="card-body">
        <h5><?= $section2_result['title']; ?></h5>
        <p><?= $section2_result['description']; ?></p>
        <a href="edit-section.php?s2_id=<?= $section2_result['id']; ?>">Edit</a>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Section 3</h4>
        </div>
      <div class="card-body">
        <h5><?= $section3_result['title']; ?></h5>
        <p><?= $section3_result['description']; ?></p>
        <a href="edit-section.php?s3_id=<?= $section3_result['id']; ?>">Edit</a>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Section 4</h4>
        </div>
      <div class="card-body">
        <h5><?= $section4_result['title']; ?></h5>
        <p><?= $section4_result['description']; ?></p>
        <a href="edit-section.php?s4_id=<?= $section4_result['id']; ?>">Edit</a>
      </div>
    </div>
    </div>
   </main>
<?php get_footer(); ?>