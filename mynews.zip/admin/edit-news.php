<?php
//connection
include_once ("lib/admin-function.php");

// update query
if (isset($_POST['u_submit'])) {
    $n_id = $_POST['u_id'];
    $n_title = $_POST['news_title'];
    $n_icon = $_POST['news_icon'];
    $n_description = htmlspecialchars($_POST['news_description']);
    $n_category = $_POST['news_category'];

    $update_news = "UPDATE news SET title='$n_title', icon='$n_icon', description='$n_description', c_id='$n_category' WHERE id='$n_id'";

    if ($conn->query($update_news)) {
        header("Location: edit-news.php?id=$n_id&status=success");
        exit();
    } else {
        error_log($conn->error);
        header("Location: edit-news.php?id=$n_id&status=error");
        exit();
    }
}
$news_add_result = "";
if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $news_add_result = "News updated successfully!";
}
$success_message = "";
if (isset($_GET['status']) && $_GET['status'] == 'add_success') {
    $success_message = "News added successfully!";
}
// select query
if (isset($_GET['id'])) {
    $news_id = $_GET['id'];

    $sel_sql = "SELECT * FROM news WHERE id = $news_id";
    $check_sql = $conn->query($sel_sql);

    if ($check_sql->num_rows > 0) {
        while ($final = $check_sql->fetch_assoc()) {


get_header();
get_sidebar();
?>

                    <div class="card mb-4">
                        <div class="card-body">
                            <?php if (!empty($success_message)) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $success_message; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php } 
                                if (!empty($news_add_result)) { ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo $news_add_result; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                <?php } ?>
                            <h3 class="mb-4">Insert News</h3>
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                        <div class="mb-3">
                                            <input value="<?= $final['id']; ?>" type="text" class="form-control" id="news_id" name="u_id" hidden required>
                                            <label for="news_title" class="form-label fw-bold">News Title</label>
                                            <input value="<?= $final['title']; ?>" type="text" class="form-control" id="news_title" name="news_title" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="news_icon" class="form-label fw-bold">News Icon</label>
                                            <input value="<?= $final['icon']; ?>" type="text" class="form-control" id="news_icon" name="news_icon" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="news_description" class="form-label fw-bold">News Description</label>
                                            <textarea class="form-control" name="news_description" rows="15" id="news_description" required><?= htmlspecialchars_decode($final['description']); ?></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label class="fw-bold">Category Name</label>
                                            <select class="form-control" name="news_category" required>
                                                <?php
                                                $sel_category = "SELECT * FROM category ORDER BY id ASC";
                                                $category_sql = $conn->query($sel_category);
                                                if ($category_sql->num_rows > 0) {
                                                    while ($category_list = $category_sql->fetch_assoc()) {
                                                        $selected = ($category_list['id'] == $final['c_id']) ? 'selected' : '';
                                                ?>
                                                <option value="<?php echo $category_list['id']; ?>" <?= $selected; ?>>
                                                    <?php echo $category_list['name']; ?>
                                                </option>
                                                <?php
                                                    }
                                                } else {
                                                ?>
                                                <option value="">No Category</option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <button class="btn btn-dark" type="submit" name="u_submit">Submit</button>
                                        <!-- <button class="btn btn-danger" type="reset">Reset</button> -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main> 
<?php
get_footer();
        }
    } else {
        header("Location:news.php");
    }
} else {
    header("Location:news.php");
}
?>
