<?php
// DB connection
include_once("lib/admin-function.php");

// Data updated
if (isset($_POST['u_submit'])) {
    $id = intval($_POST['u_id']);
    $table_name = $_POST['table_name']; // Auto table name select

    // Secure table whitelist
    $allowed_tables = ['footer_1', 'usefull_link'];

    if (in_array($table_name, $allowed_tables)) {
        if ($table_name === 'footer_1') {
            $web_title = $conn-> real_escape_string($_POST['web_title']);
            $web_des = $conn-> real_escape_string($_POST['web_des']);
            $usefull_title = $conn-> real_escape_string($_POST['usefull_title']);
            $contact_title = $conn-> real_escape_string($_POST['contact_title']);
            $contact_info = $conn-> real_escape_string($_POST['contact_info']);
            $sub_title = $conn-> real_escape_string($_POST['sub_title']);
            $sub_des = $conn-> real_escape_string($_POST['sub_des']);
            $footer_bottom = $conn-> real_escape_string($_POST['footer_bottom']);

            $update_sql = "UPDATE footer_1 SET 
                web_title = '$web_title',
                web_des = '$web_des',
                usefull_title = '$usefull_title',
                contact_title = '$contact_title',
                contact_info = '$contact_info',
                sub_title = '$sub_title',
                sub_des = '$sub_des',
                footer_bottom = '$footer_bottom'
                WHERE id = $id";
        }else {
            $title = $conn->real_escape_string($_POST['title']);
            $link = $conn->real_escape_string($_POST['link']);

            $update_sql = "UPDATE usefull_link SET 
                title = '$title',
                link = '$link'
                WHERE id = $id";
        }

        // Query
        if ($conn-> query($update_sql) === TRUE) {
            header("Location: footer.php?status=success");
            exit();
        }else {
            echo "Update failed: " .$conn-> error;
        }
    }else {
        echo "Invalid table name!";
    }
}


// Edit button Id find
if (isset($_GET['f1_id']) || isset($_GET['f2_id'])) {
    

    if (isset($_GET['f1_id'])) {
        $f1_id = intval($_GET['f1_id']);
        $footer1_sql = "SELECT * FROM footer_1 WHERE id = $f1_id";
        $f1_sql = $conn-> query($footer1_sql);

        if ($f1_sql-> num_rows > 0) {
            $final1 = $f1_sql-> fetch_assoc();
        }else {
            header("Location: footer.php");
            exit();
        }
    }

    if (isset($_GET['f2_id'])) {
        $f2_id = intval($_GET['f2_id']);
        $footer2_sql = "SELECT * FROM usefull_link WHERE id = $f2_id";
        $f2_sql = $conn-> query($footer2_sql);

        if ($f2_sql-> num_rows > 0) {
            $final2 = $f2_sql-> fetch_assoc();
        }
    }


get_header();
get_sidebar();
?>

<div class="card mb-4">
    <div class="card-body">
        <h3 class="mb-4">Edit Section Info</h3>

        <div class="row">
            <div class="col-lg-6">
                <?php if (!empty($final1)) { ?>
                    <!-- Form for footer_1 -->
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                        <input value="<?= $final1['id']; ?>" type="hidden" name="u_id" required>
                        <input value="footer_1" type="hidden" name="table_name">
                        <h4 class="text-capitalize mt-5 mb-3 text-center">Row 1</h4>
                        <div class="mb-3">
                            <label for="web_title" class="form-label fw-bold">Web Title</label>
                            <input value="<?= $final1['web_title']; ?>" type="text" class="form-control" id="web_title" name="web_title" required>
                        </div>

                        <div class="mb-3">
                            <label for="web_des" class="form-label fw-bold">Web Description</label>
                            <textarea class="form-control" name="web_des" rows="5" id="web_des" required><?= htmlspecialchars($final1['web_des']); ?></textarea>
                        </div>

                        <h4 class="text-capitalize mt-5 mb-3 text-center">Row 2</h4>
                        <div class="mb-3">
                            <label for="usefull_title" class="form-label fw-bold">Contact Title</label>
                            <input value="<?= $final1['usefull_title']; ?>" type="text" class="form-control" id="usefull_title" name="usefull_title" required>
                        </div>

                        <h4 class="text-capitalize mt-5 mb-3 text-center">Row 3</h4>
                        <div class="mb-3">
                            <label for="description1" class="form-label fw-bold">Contact Title</label>
                            <input value="<?= $final1['contact_title']; ?>" type="text" class="form-control" id="description1" name="contact_title" required>
                        </div>

                        <div class="mb-3">
                            <label for="contact_info" class="form-label fw-bold">Contact Info</label>
                            <textarea class="form-control" name="contact_info" rows="5" id="contact_info" required><?= htmlspecialchars($final1['contact_info']); ?></textarea>
                        </div>

                        <h4 class="text-capitalize mt-5 mb-3 text-center">Row 4</h4>
                        <div class="mb-3">
                            <label for="sub_title" class="form-label fw-bold">Subscription Title</label>
                            <input value="<?= $final1['sub_title']; ?>" type="text" class="form-control" id="sub_title" name="sub_title" required>
                        </div>

                        <div class="mb-3">
                            <label for="sub_des" class="form-label fw-bold">Subscription Description</label>
                            <textarea class="form-control" name="sub_des" rows="5" id="sub_des" required><?= htmlspecialchars($final1['sub_des']); ?></textarea>
                        </div>

                        <h4 class="text-capitalize mt-5 mb-3 text-center">Footer Bottom</h4>
                        <div class="mb-3">
                            <label for="footer_bottom" class="form-label fw-bold">Text</label>
                            <textarea class="form-control" name="footer_bottom" rows="5" id="footer_bottom" required><?= htmlspecialchars($final1['footer_bottom']); ?></textarea>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>

                <?php if (!empty($final2)) { ?>
                    <!-- Form for usefull_link -->
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="mt-5">
                        <input value="<?= $final2['id']; ?>" type="hidden" name="u_id" required>
                        <input value="usefull_link" type="hidden" name="table_name">

                        <div class="mb-3">
                            <label for="title" class="form-label fw-bold">Title</label>
                            <input value="<?= $final2['title']; ?>" type="text" class="form-control" id="title" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="link" class="form-label fw-bold">link</label>
                            <input value="<?= $final2['link']; ?>" type="text" class="form-control" id="link" name="link" required>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

</div>
</main>
<?php
    get_footer();
 }else {
    header("Location: footer.php");
    exit();
} ?>