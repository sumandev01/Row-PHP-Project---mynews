<?php 
    include_once("function/function.php");

    $message = "";

    // Contact form table query
    if (isset($_POST['submit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = htmlspecialchars($_POST['message']);

        $cform_sql = "INSERT INTO contact_form (name, email, message) VALUES('$name', '$email', '$message')";

        if ($conn-> query($cform_sql)) {
            $message = "Thank you! We’ve received your message and will get back to you soon.";
        }else {
            die($conn-> error);
        }
    }

    // Contact table query
    $contact_sql = "SELECT * FROM contact";
    $conn_contact = $conn-> query($contact_sql);

    if ($conn_contact-> num_rows > 0) {
        $final = $conn_contact-> fetch_assoc();
    }
    get_header();

?>

<?php
    // Contact form submition thank you message
    if (!empty($message)) : ?>
        <div id="subscribeSuccess" class="alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-4 shadow" role="alert" style="z-index: 9999; min-width: 300px;">
            ✅ <?= htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
<?php endif; ?>

    <!-- Contact Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="fw-bold mb-4 text-center"><?= $final['title'] ?></h2>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="text-center mb-4">
                        <?= nl2br(htmlspecialchars_decode($final['description'])); ?>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" >
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="4" placeholder="Your Message"></textarea>
                        </div>
                        <button type="submit" class="btn btn-dark w-100" name="submit">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php 
    get_footer();

?>