<?php
//connection
include_once ("lib/admin-function.php");

//insert message
//$result = "";
$error = "";
//form submition
if (isset($_POST['news_submit'])) {
 $news_title = $_POST['news_title'];
 $news_icon = $_POST['news_icon'];
 $news_desc = htmlspecialchars($_POST['news_desc']);
 $news_category = $_POST['category_name'];
 $news_pass = md5($_POST['n_pass']);
 $news_cpass = md5($_POST['c_pass']);
 $user_id = $_POST['user_id'];

 if ($news_pass == $news_cpass) {
  $check_sql = "SELECT * FROM news WHERE title = '$news_title'";
  $check_result = $conn-> query($check_sql);
  if ($check_result-> num_rows > 0) {
    $i = 1;
    while ($check_result-> num_rows > 0) {
      $new_title = $news_title . " #" . $i;
      $check_result = $conn-> query("SELECT * FROM news WHERE title = '$new_title'");
      $i++;
    }
    //set new title
    $news_title = $new_title;
  }

  $insert_sql = "INSERT INTO news(title, icon, description, pass, c_id, user_id) VALUES ('$news_title', '$news_icon', '$news_desc', '$news_pass', '$news_category', '$user_id')";

  if ($conn->query($insert_sql)) {
    $last_id = $conn->insert_id;

    // Redirect with status=success
    header("Location: edit-news.php?id=" . $last_id . "&status=add_success");
    exit();
}else{
   die($conn-> error);
  }
 }else{
  $error = "<h5 class='text-danger'>Password not matched</h5>";
 }


}

get_header();
get_sidebar();

?>

     <div class="card mb-4">
      <div class="card-body">
       <h3 class="mb-4">Insert News</h3>
       <div class="row">
        <div class="col-lg-12">
         <!-- News Insert Form Start -->
         <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="">
          <!-- Users id -->
          <input type="hidden" name="user_id" value="<?php echo $_SESSION['id']; ?>">
          <div class="mb-3">
           <label for="news_title" class="form-label">News Title</label>
           <input type="text" class="form-control" id="news_title" name="news_title" required>
          </div>
          <div class="mb-3">
           <label for="news_icon" class="form-label">News Icon</label>
           <input type="text" class="form-control" id="news_icon" name="news_icon" required>
          </div>
          <div class="mb-3">
           <label for="news_desc" class="form-label">News Description</label>
           <textarea class="form-control" name="news_desc" rows="5" id="news_desc" required></textarea>
          </div>
          <div class="mb-3">
           <label for="">Category Name</label>
           <select class="form-control" name="category_name" id="" required>
            <option value="">Select Category</option>
            <?php 
            $sel_category = "SELECT * FROM category ORDER BY id ASC";
             $category_sql = $conn-> query($sel_category);
             if ($category_sql-> num_rows > 0) {
              while($category_list = $category_sql-> fetch_assoc()){
            ?>
            <option value="<?php echo $category_list['id']; ?>"><?php echo $category_list['name']; ?></option>
            <?php }
              }else{ ?>
            <option value="">No Category</option>
            <?php } ?>
           </select>
          </div>
          <div class="mb-3">
           <label for="n_pass">Password</label>
           <input type="password" class="form-control" id="n_pass" name="n_pass">
          </div>
          <div class="mb-3">
           <label for="c_pass">Confriam Password</label>
           <input type="password" class="form-control" id="c_pass" name="c_pass">
          </div>
          <button class="btn btn-dark" type="submit" name="news_submit">Submit</button>
          <button class="btn btn-danger" type="reset">Reset</button>
         </form>
         <!-- News Insert Form End -->
         <div class="error_message mt-3">
          <?php echo $error; ?>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </main>
<?php get_footer(); ?>