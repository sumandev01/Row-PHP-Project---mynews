<?php
//connection
    include_once ("lib/admin-function.php");

   if (isset($_POST['update'])) {
       $faq = $_POST['faq'];
       $ans = htmlspecialchars($_POST['ans']);
       $id = intval($_POST['id']);

       $faq_sql = "UPDATE faq SET faq='$faq', ans='$ans' WHERE id = $id";

       if ($conn-> query($faq_sql)) {
           header("Location: faq-page.php?status=success");
       }else {
        die($conn-> error);
       }
   }

   // FAQ edit id find
   if (isset($_GET['id'])) {
       $id = intval($_GET['id']);

       $faq_sql = "SELECT * FROM faq WHERE id = $id";
       $faq_check = $conn-> query($faq_sql);

       if ($faq_check-> num_rows > 0) {
           while($faq_result = $faq_check-> fetch_assoc()) {



    get_header();
    get_sidebar();

?>      <div class="card mb-4">
            <div class="card-header">
                <h3 class="fw-bold">Edit FAQ</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <input value="<?= $faq_result['id']; ?>" type="text" name="id" hidden>
                    <div class="mb-3">
                        <label for="faq" class="form-label fw-bold">FAQ</label>
                        <input value="<?= $faq_result['faq']; ?>" type="text" class="form-control" id="faq" name="faq" required>
                    </div>
                    <div class="mb-3">
                        <label for="ans" class="form-label fw-bold">Ans</label>
                        <textarea name="ans" id="ans" class="form-control" rows="7"><?= $faq_result['ans'] ?></textarea>
                    </div>
                    <button type="submit" name="update" type="button" class="btn btn-dark">Update Now</button>
                </form>
            </div>
        </div>
    </div>
   </main>
<?php get_footer(); 


               }
       }else {
        header("Location: faq-page.php");
       }
   }else {
    header("Location: faq-page.php");
   }


?>