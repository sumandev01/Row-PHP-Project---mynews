<?php
//connection
include_once ("lib/admin-function.php");

$update_message = "";
$add_link_message = "";
$deleted_link_message = "";

// Footer 1 table query
$footer1_sql = "SELECT * FROM footer_1";
$conn_footer1 = $conn-> query($footer1_sql);
if ($conn_footer1-> num_rows > 0) {
    $footer_result = $conn_footer1-> fetch_assoc();
}else {
    $footer_result = [
        'id' => 0,
        'web_title' => 'Data not found',
        'web_des' => 'Data not found',
        'usefull_title' => 'Data not found',
        'contact_title' => 'Data not found',
        'contact_info' => 'Data not found',
        'sub_title' => 'Data not found',
        'sub_des' => 'Data not found',
        'footer_bottom' => 'Data not found',
    ];
}
// Usefull link table query
$footer2_sql = "SELECT * FROM usefull_link";
$conn_footer2 = $conn-> query($footer2_sql);

// Success message
if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $update_message = '<div class="alert alert-success">Updated successfully!</div>';
}
// Usefull link added message
if (isset($_GET['addstatus']) && $_GET['addstatus'] === 'success') {
    $add_link_message = '<div class="alert alert-success">Usefull link add successfully!</div>';
}

// Usefull link deleted message
if (isset($_GET['deleted']) && $_GET['deleted'] === 'success') {
    $deleted_link_message = '<div class="alert alert-danger">Usefull link deleted successfully!</div>';
}

get_header();
get_sidebar();

?>
  <div class="update-message mb-4">
        <?= $update_message; ?>
        <?= $add_link_message; ?>
        <?= $deleted_link_message; ?>
    </div>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="fw-bold mb-0">Footer info</h3>
            <h5><a class="nav-link d-inline-block mb-0" href="edit-footer.php?f1_id=<?= $footer_result['id']; ?>">Edit</a></h5>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Row 1</h4>
        </div>
      <div class="card-body">
        <h5><?= $footer_result['web_title']; ?></h5>
        <p><?= $footer_result['web_des']; ?></p>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Row 2</h4>
        </div>
      <div class="card-body">
        <h5><?= $footer_result['usefull_title']; ?></h5>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Row 3</h4>
        </div>
      <div class="card-body">
        <h5><?= $footer_result['contact_title']; ?></h5>
        <p><?= $footer_result['contact_info']; ?></p>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Row 4</h4>
        </div>
      <div class="card-body">
        <h5><?= $footer_result['sub_title']; ?></h5>
        <p><?= $footer_result['sub_des']; ?></p>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="text-capitalize">Footer Bottom</h4>
        </div>
      <div class="card-body">
        <p><?= $footer_result['footer_bottom']; ?></p>
      </div>
    </div>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="text-capitalize">Useful Links</h4>
            <h5><a class="nav-link d-inline-block mb-0" href="add-usefull-link.php">Add Link</a></h5>
        </div>
      <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th style="width: 40%;">Title</th>
                    <th style="width: 40%;">Link</th>
                    <th style="width: 20%;">Edit/Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($conn_footer2->num_rows > 0) {
                    while($footer2_result = $conn_footer2->fetch_assoc()){ ?>
                        <tr>
                            <td><?= $footer2_result['title']; ?></td>
                            <td><?= $footer2_result['link']; ?></a></td>
                            <td>
                                <a href="edit-footer.php?f2_id=<?= $footer2_result['id']; ?>">edit</a>
                                <span>/</span>
                                <a href="delete.php?del=<?= $footer2_result['id']; ?>">delete</a>
                            </td>
                        </tr>
                <?php } } else { ?>
                    <tr>
                        <td colspan="3">No Data</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
      </div>
    </div>
    </div>
   </main>
<?php get_footer(); ?>