<?php
//connection
include_once ("lib/admin-function.php");

$success_msg = "";

// Update query
if (isset($_POST['banner_submit'])) {
  $b_title = $_POST['banner_title'];
  $b_des = $_POST['banner_description'];
  $b_icon = $_POST['banner_icon'];
  $b_link = $_POST['banner_link'];
  $b_id = $_POST['id']; // get id from hidden input

  $update = "UPDATE banner SET banner_title='$b_title', banner_des='$b_des', banner_link='$b_link', banner_icon='$b_icon' WHERE id =$b_id";
  if ($conn-> query($update)) {
    header("Location: home-page.php?status=success");
  }else{
    die($conn-> error);
  }
}


$sel_bsql = "SELECT * FROM banner";

  $banner_result = $conn-> query($sel_bsql);
  if ($banner_result-> num_rows > 0) {
    while($b_result = $banner_result -> fetch_assoc()){
      $final = $b_result;
    }
  }

  get_header();
  get_sidebar();
?>
      <div class="card mb-4">
        <div class="card-body">
          <h3 class="mb-4">Update Banner Information</h3>
          <div class="row">
            <div class="col-lg-12">
             <!-- Category Insert Form Start -->
             <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="">
              <input type="hidden" name="id" value="<?php echo $final['id']; ?>" />
              <div class="mb-3">
                 <label for="banner_title" class="form-label">Title</label>
                 <input value="<?php echo $final['banner_title'] ?>" type="text" class="form-control" id="banner_title" name="banner_title" required>
             </div>
             <div class="mb-3">
                 <label for="banner_description" class="form-label">Description</label>
                 <textarea class="form-control" name="banner_description" rows="5" id="banner_description" required><?= htmlspecialchars_decode($final['banner_des']); ?></textarea>
             </div>
             <div class="mb-3">
                 <label for="banner_icon" class="form-label">Icon</label>
                 <input value="<?php echo $final['banner_icon'] ?>" type="text" class="form-control" id="banner_icon" name="banner_icon" required>
             </div>
             <div class="mb-3">
                 <label for="banner_link" class="form-label">Link</label>
                 <input value="<?php echo $final['banner_link'] ?>" type="text" class="form-control" id="banner_link" name="banner_link" required>
             </div>
             <button class="btn btn-dark" type="submit" name="banner_submit">Update</button>
         </form>
     </div>
  </div>
  </div>
  </div>
  </div>
  </main>
<?php get_footer(); ?>
