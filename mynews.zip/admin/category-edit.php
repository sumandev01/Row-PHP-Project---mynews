<?php ob_start();
//connection
include_once ("lib/admin-function.php");

get_header();
get_sidebar();

$success_msg = "";

//update query
if (isset($_POST['u_submit'])) {
  $c_name = $_POST['category_name'];
  $c_icon = $_POST['category_icon'];
  $u_id = $_POST['id']; // get id from hidden input

  $update = "UPDATE category SET name='$c_name', icon='$c_icon' WHERE id =$u_id";
  if ($conn-> query($update)) {
    $success_msg = "Category updated successfully";
  }else{
    die($conn-> error);
  }
}

//select query
if (isset($_GET['id'])) {
  
  $e_id = $_GET['id'];

  $sel_sql = "SELECT * FROM category WHERE id=$e_id";

  $r_sql = $conn-> query($sel_sql);

  if ($r_sql-> num_rows > 0) {
    while($final = $r_sql -> fetch_assoc()){

?>
      <div class="card mb-4">
          <div class="card-body">
            <h3 class="mb-4">Insert Category</h3>
            <div class="row">
              <div class="col-lg-4">
               <!-- Category Insert Form Start -->
               <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="">
                <input type="hidden" name="id" value="<?php echo $final['id']; ?>" />
                <div class="mb-3">
                 <label for="category_name" class="form-label">Category Name</label>
                 <input value="<?php echo $final['name'] ?>" type="text" class="form-control" id="category_name" name="category_name" required>
             </div>
             <div class="mb-3">
                 <label for="category_icon" class="form-label">Category Icon</label>
                 <input value="<?php echo $final['icon'] ?>" type="text" class="form-control" id="category_icon" name="category_icon" required>
             </div>
             <button class="btn btn-dark" type="submit" name="u_submit">Update</button>
         </form>
     </div>
  </div>
  </div>
  </div>
  </div>
  </main>
<?php
get_footer();
    }
  }else{
    header("Location:category.php");
  }

}else{
  header("Location:category.php");
} ?>
