<?php
// Start the session
session_start();

// Unset session variables
session_unset(); // This will remove all session variables

// Destroy the session
session_destroy(); // This will destroy the session

// Delete cookies (if they exist)
setcookie('user_data', '', time() - 3600, '/');

// Redirect the user to the login page
header("Location: login.php");
exit;
?>