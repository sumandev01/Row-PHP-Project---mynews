<?php
//connection
include_once ("lib/admin-function.php");

get_header();
get_sidebar();

  //insert message
$insert_message = NULL;
  //form submition
if (isset($_POST['category_submit'])) {
    $cname = $_POST['category_name'];
    $cicon = $_POST['category_icon'];
    //category data insert
    $insert_category = "INSERT INTO category(name, icon) VALUES ('$cname', '$cicon')";
    //check category data
    if ($conn-> query($insert_category)) {
      $insert_message = "Category create successfully";
  }else{
      die($conn-> error);
  }
}


if (isset($_GET['error']) && $_GET['error'] == 'default_category_delete_not_allowed') {
    echo "<p style='color:red;'>Default category can not be deleted!</p>";
}

if (isset($_GET['deleted']) && $_GET['deleted'] == 'success') {
    echo "<p style='color:green;'>Deleted successfully.</p>";
}



//select query
$select_sql = "SELECT * FROM category";
$s_sql = $conn-> query($select_sql);
//echo $s_sql-> num_rows;
?>

    <div class="card mb-4">
        <div class="card-body">
          <h3 class="mb-4">Insert Category</h3>
          <div class="row">
            <div class="col-lg-4">
             <!-- Category Insert Form Start -->
             <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="">
              <div class="mb-3">
               <label for="category_name" class="form-label">Category Name</label>
               <input type="text" class="form-control" id="category_name" name="category_name" required>
           </div>
           <div class="mb-3">
               <label for="category_icon" class="form-label">Category Icon</label>
               <input type="text" class="form-control" id="category_icon" name="category_icon" required>
           </div>
           <button class="btn btn-dark" type="submit" name="category_submit">Submit</button>
           <button class="btn btn-danger" type="reset">Reset</button>
       </form>
       <!-- Category Insert Form End -->
       <div class="insert_category">
           <?php echo $insert_message; ?>
       </div>
   </div>
</div>
</div>
</div>
<div class="card mb-4">
   <div class="card-body">
      <h3 class="mb-4">Category info</h3>
      <table id="datatablesSimple">
        <thead>
            <tr>
              <th>Sl</th>
              <th>Name</th>
              <th>Icon</th>
              <th>Edit/Delate</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $count = 0;
        if ($s_sql-> num_rows >0) { 
        while ($category_list = $s_sql -> fetch_assoc()) {
            $count++; // Auto number count
        ?>
        <tr>
            <td><?php echo $count; ?></td>
            <td><?php echo $category_list['name'] ?></td>
            <td><?php echo $category_list['icon'] ?></td>
            <td>
                <a href="category-edit.php?id=<?php echo $category_list['id']; ?>">Edit</a>
                <span>/</span>
                <a href="delete.php?category_delete=<?php echo $category_list['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php } 
          }else{ ?>
        <tr>
            <td>No data to show</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <?php } ?>
        </tbody>
</table>
</div>
</div>
</div>
</main>
<?php get_footer(); ?>