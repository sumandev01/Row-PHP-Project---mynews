<?php session_start();
	include_once(__DIR__. "/../lib/db.php");

	// Header
	function get_header() {
		include_once(__DIR__. "/../lib/header.php");
	}


	// Footer
	function get_footer(){
		include_once(__DIR__."/../lib/footer.php");
	}




?>