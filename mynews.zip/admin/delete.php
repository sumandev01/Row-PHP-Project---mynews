<?php
// db connection
include("../lib/db.php");

if (isset($_GET['category_delete'])) {
    $d_id = (int)$_GET['category_delete'];
    // Check id = 1 not delete 
    if ($d_id === 1) {
        header("Location:category.php?error=default_category_delete_not_allowed");
        exit();
    }
    // Step 1: News table c_id defualt 1 set
    $update_news = "UPDATE news SET c_id = 1 WHERE c_id = $d_id";
    $conn-> query($update_news);

    // Step 2: Category delete
    $delete_data = "DELETE FROM category WHERE id = $d_id";

    if ($conn-> query($delete_data)) {
        header("Location: category.php?deleted=success");
        exit();
    }else {
        header("Location: category.php");
        exit();
    }
}elseif (isset($_GET['news_delete'])) {
        $nd_id = (int)$_GET['news_delete'];

        // News delete
        $delete_news = "DELETE FROM news WHERE id = $nd_id";

        if ($conn-> query($delete_news)) {
            header("Location: news.php?deleted=success");
            exit();
        }else {
            header("Location: news.php");
            exit();
        }
    }
    elseif (isset($_GET['del'])) {
        $ulink = (int)$_GET['del'];

        // Usefull link delete
        $delete_ulink = "DELETE FROM usefull_link WHERE id = $ulink";

        if ($conn-> query($delete_ulink)) {
            header("Location: footer.php?deleted=success");
            exit();
        }else {
            header("Location: footer.php");
            exit();
        }
    }
    elseif(isset($_GET['del-faq'])) {
        $faq = (int)$_GET['del-faq'];

        // FAQ delete
        $delete_faq = "DELETE FROM faq WHERE id = $faq";

        if ($conn-> query($delete_faq)) {
            header("Location: faq-page.php?deleted=success");
            exit();
        }else {
            header("Location: faq-page.php");
            exit();
        }
    }

?>

