<?php
//connection
include_once ("lib/admin-function.php");

get_header();
get_sidebar();

$sel_news = "SELECT news.id, news.title, news.description, news.icon, category.name FROM news INNER JOIN category ON news.c_id = category.id ORDER BY news.id DESC";

$s_sql = $conn-> query($sel_news);
    //echo $s_sql-> num_rows;


if (isset($_GET['deleted']) && $_GET['deleted'] == 'success') {
    echo "<p class='text-success'>Deleted Successfully</p>";
}
?>

     <div class="card mb-4">
      <div class="card-body">
       <a class="nav-link d-inline-block" href="add-news.php">Add News</a>
      </div>
     </div>
     <div class="card mb-4">
      <div class="card-body">
       <h3 class="mb-4">News info</h3>
       <table id="datatablesSimple">
        <thead>
         <tr>
          <th style="width: 25%;">Title</th>
          <th>Description</th>
          <th style="width: 15%;">Icon</th>
          <th style="width: 15%;">Category</th>
          <th>Edit/Delate</th>
         </tr>
        </thead>
        <tbody>
         <?php if ($s_sql-> num_rows >0) { ?>
          <?php while ($news_list = $s_sql -> fetch_assoc()) { ?>
           <tr>
            <td><?php echo $news_list['title']; ?></td>
            <td><?php $sdescription = $news_list['description'];
                $words = explode(' ', $sdescription);
                if (count($words) >= 20) {
                    $short_description = implode(' ', array_slice($words, 0, 20)) . ' ....';
                }else {
                    $short_description = $sdescription;
                }
                
                echo $short_description;
                ?>
             </td>
             <td><?php echo $news_list['icon'] ?></td>
             <td><?php echo $news_list['name'] ?></td>
            <td>
             <a href="edit-news.php?id=<?php echo $news_list['id']; ?>">Edit</a>
             <span>/</span>
             <a href="delete.php?news_delete=<?php echo $news_list['id']; ?>">Delete</a>
            </td>
           </tr>
          <?php } ?>
         <?php }else{ ?>
          <tr>
           <td>No data to show</td>
           <td></td>
           <td></td>
           <td></td>
          </tr>
         <?php } ?>
        </tbody>
       </table>
      </div>
     </div>
    </div>
   </main>
<?php get_footer(); ?>