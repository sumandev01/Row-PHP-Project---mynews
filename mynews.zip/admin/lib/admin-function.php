<?php 
	session_start();
	//db connection
	include_once(__DIR__ . "/../../lib/db.php");


	//Header function
	function get_header() {
		include_once "admin-header.php";
	}

	//Sidebar function
	function get_sidebar() {
		include_once "admin-sidebar.php";
	}

	//Footer function
	function get_footer() {
		include_once("admin-footer.php");
	}

    //page title & breadcrumb
    function getPageTitles() {
        $uri = $_SERVER['PHP_SELF'];
        $uri_parts = explode('/', trim($uri, '/'));

        //admin page find
        $adminIndex = array_search('admin', $uri_parts);

        if ($adminIndex !== false) {
            $uri_parts = array_slice($uri_parts, $adminIndex + 1);
        }

        $titles = [];
        foreach ($uri_parts as $part) {
            $filename = basename($part, '.php');
            $title = ucwords(str_replace(['-', '_'], ' ', basename($part, '.php')));
            $titles[] = $title;
        }
        array_unshift($titles, 'Dashboard');
        
        return $titles;
    }



	//Login Session
	if (!isset($_SESSION['id'])) {
        if (isset($_COOKIE['user_data'])) {
            $user_data =  json_decode($_COOKIE['user_data'], true);
            $_SESSION['id'] = $user_data['id'];
            $_SESSION['name'] = $user_data['name'];
            $_SESSION['email'] = $user_data['email'];
        }else {
            header("Location:login.php");
        }
    }

?>