<?php 
include_once("function/function.php");

$nf_result = null;

  // Category table query
  $category_sql = "SELECT * FROM category ORDER BY id DESC LIMIT 6";
  $category_conn = $conn-> query($category_sql);

//News single page
if (isset($_GET['id'])) {
    $sn_id = intval($_GET['id']); // নিরাপদ করার জন্য intval()

    $news_sql = "SELECT news.id, news.title, news.description, news.icon, category.name FROM news INNER JOIN category ON news.c_id = category.id WHERE news.id = $sn_id";

    $news_conn = $conn->query($news_sql);

    if ($news_conn->num_rows > 0) {
        $nf_result = $news_conn->fetch_assoc();
    }else {
      header("Location: index.php");
      exit();
    }

    get_header();
?>
    <!-- detail news start -->
    <section class="education">
      <div class="container">

        <div class="row">
          <div class="col-lg-8">
            <div class="c_news text-left details">
              <i class="<?= $nf_result['icon']; ?>" aria-hidden="true"></i>
              <ul class="list-inline">
                <li class="list-inline-item"><a class="text-uppercase" href="#"><?= $nf_result['name']; ?></a></li>
                <li class="list-inline-item"><a href="#">author</a></li>
              </ul>
              <h2><?= $nf_result['title']; ?></h2>
              <p><?= nl2br(htmlspecialchars_decode($nf_result['description'])); ?></p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar bg-dark text-white">
              <p>sidebar content</p>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- detail news end -->

    <!-- category start -->
    <section class="category">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="c_title text-center">
              <h1>Popular Categories</h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet consectetur adipisicing elit. consectetur adipisicing elit. </p>
              <hr class="w-25 m-auto">
            </div>
          </div>
        </div>
        <div class="row">
          <?php 
            if ($category_conn-> num_rows > 0) {
               while($category_final = $category_conn-> fetch_assoc() ) { ?>
              <div class="col-lg">
                <div class="f_icon text-center">
                  <a href="#" class="text-dark">
                    <i class="<?= $category_final['icon'];?>" aria-hidden="true"></i>
                  </a>
                  <h3><?= $category_final['name'];?></h3>
                </div>
              </div>
          <?php } }else { ?>
              <div class="col-lg">
                <div class="f_icon text-center">
                  <a href="#" class="text-dark">
                    <i class="fa fa-book" aria-hidden="true"></i>
                  </a>
                  <h3>No Category</h3>
                </div>
              </div>
          <?php } ?>
        </div>
      </div>
    </section>
    <!-- category end -->
<?php
    
    get_footer();

       }else {
  header("Location: index.php");
  exit();
} ?>