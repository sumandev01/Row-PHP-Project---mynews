<?php 
  include_once("function/function.php");
  // Banner table query
  $banner_sql = "SELECT * FROM banner";
  $banner_sql_check = $conn-> query($banner_sql);
  if ($banner_sql_check-> num_rows > 0) {
    while($banner_check = $banner_sql_check -> fetch_assoc()) {
        $banner_result = $banner_check;
      }
    }

  // Category table query
  $category_sql = "SELECT * FROM category ORDER BY id DESC LIMIT 6";
  $category_conn = $conn-> query($category_sql);

  // News table tech category query
  $news_sql = "SELECT news.id, news.title, news.icon, news.description FROM news WHERE c_id=4 ORDER BY id DESC LIMIT 3";
  $news_sql_check = $conn-> query($news_sql);


  // News table health category query
  $newsHealth_sql = "SELECT news.id, news.title, news.icon, news.description FROM news WHERE c_id=9 ORDER BY id DESC LIMIT 3";
  $newsHealth_check = $conn->query($newsHealth_sql);

  // News table education category query
  $newsEducation_sql = "SELECT news.id, news.title, news.icon, news.description FROM news WHERE c_id=1 ORDER BY id DESC LIMIT 3";
  $newsEducation_check = $conn->query($newsEducation_sql);


  // Section 1 table query
  $section1_sql = "SELECT * FROM home_section1";
  $conn_section1 = $conn-> query($section1_sql);
  if ($conn_section1-> num_rows > 0) {
      $section1_result = $conn_section1-> fetch_assoc();
  }

  // Section 2 table query
  $section2_sql = "SELECT * FROM home_section2";
  $conn_section2 = $conn-> query($section2_sql);
  if ($conn_section2-> num_rows > 0) {
      $section2_result = $conn_section2-> fetch_assoc();
  }

  // Section 3 table query
  $section3_sql = "SELECT * FROM home_section3";
  $conn_section3 = $conn-> query($section3_sql);
  if ($conn_section3-> num_rows > 0) {
      $section3_result = $conn_section3-> fetch_assoc();
  }
  // Section 4 table query
  $section4_sql = "SELECT * FROM home_section4";
  $conn_section4 = $conn-> query($section4_sql);
  if ($conn_section4-> num_rows > 0) {
      $section4_result = $conn_section4-> fetch_assoc();
  }

  get_header();
?>
    <!-- banner start -->
    <section class="banner">
      <div class="container">
        <div class="row mh_custom align-items-center">
          <div class="col-lg-7">
            <div class="b_content">
              <h1><?php echo $banner_result['banner_title']; ?></h1>
              <p><?php echo $banner_result['banner_des']; ?></p>
              <a href="<?php echo $banner_result['banner_link']; ?>" class="btn btn-dark">Read More</a>
            </div>

          </div>
          <div class="col-lg-5">
            <div class="b_icon text-center">
              <i class="<?php echo $banner_result['banner_icon']; ?>" aria-hidden="true"></i>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- banner end -->
    <!-- category start -->
    <section class="category">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="c_title text-center">
              <h1><?= $section1_result['title']; ?></h1>
              <p><?= $section1_result['description']; ?></p>
              <hr class="w-25 m-auto">
            </div>
          </div>
        </div>
        <div class="row">
        <?php 
            if ($category_conn-> num_rows > 0) {
              while($category_final = $category_conn-> fetch_assoc() ) { ?>
              <div class="col-lg">
                <div class="f_icon text-center">
                  <a href="#" class="text-dark">
                    <i class="<?= $category_final['icon'];?>" aria-hidden="true"></i>
                  </a>
                  <h3><?= $category_final['name'];?></h3>
                </div>
              </div>
          <?php } }else { ?>
              <div class="col-lg">
                <div class="f_icon text-center">
                  <a href="#" class="text-dark">
                    <i class="fa fa-book" aria-hidden="true"></i>
                  </a>
                  <h3>No Category</h3>
                </div>
              </div>
          <?php } ?>
        </div>
      </div>
    </section>
    <!-- featcategory end -->
    <!-- tech news start -->
    <section class="tech">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="c_title text-center">
              <h1><?= $section2_result['title']; ?></h1>
              <p><?= $section2_result['description']; ?></p>
              <hr class="w-25 m-auto">
            </div>
          </div>
        </div>
        <div class="row">
          <?php 
            if ($news_sql_check-> num_rows > 0) {
              while($news_result = $news_sql_check-> fetch_assoc()) { ?>
                <div class="col-lg-4">
                  <div class="c_news text-center">
                    <i class="<?php echo $news_result['icon']; ?>" aria-hidden="true"></i>
                    <h2><?php echo $news_result['title']; ?></h2>
                    <p><?php 
                    
                    $data = $news_result['description']; 

                    if (strlen($data) > 150) {
                      echo substr($data, 0, 150) . "...." . "<br>";
                      echo "<a href='single.php?id=". $news_result['id'] ."' class='text-dark mt-3'>read more</a>";
                    }else {
                      echo $data;
                    }
                    ?></p>
                  </div>
                </div>
          <?php  }
              }else { ?>

                <div class="col-lg-4">
                  <div class="c_news text-center">
                    <h2>Data not found!</h2>
                  </div>
                </div>
          <?php } ?>
        </div>
      </div>
    </section>
    <!-- tech news end -->
    <!-- health news start -->
    <section class="health">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="c_title text-center">
              <h1><?= $section3_result['title']; ?></h1>
              <p><?= $section3_result['description']; ?></p>
              <hr class="w-25 m-auto">
            </div>
          </div>
        </div>
        <div class="row">
          <?php 
            if ($newsHealth_check-> num_rows > 0) {
              while($nhealth_result = $newsHealth_check-> fetch_assoc()){
          ?>
          <div class="col-lg-4">
            <div class="c_news text-center">
              <i class="<?php echo $nhealth_result['icon']; ?>" aria-hidden="true"></i>
              <h2><?php echo $nhealth_result['title']; ?></h2>
              <p><?php 
                $data = $nhealth_result['description'];

                if (strlen($data) > 150) {
                  echo substr($data, 0, 150) . "...." . "<br>";
                  echo "<a href='single.php?id=" . $nhealth_result['id'] . "' class='text-dark'>read more</a>";
                }
              ?></p>
            </div>
          </div>
          <?php }
            }else { ?>
          <div class="col-lg-4">
            <div class="c_news text-center">
              <h2>Data not found!</h2>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </section>
    <!-- health news end -->
    <!-- education news start -->
    <section class="education">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="c_title text-center">
              <h1><?= $section4_result['title']; ?></h1>
              <p><?= $section4_result['description']; ?></p>
              <hr class="w-25 m-auto">
            </div>
          </div>
        </div>
        <div class="row">
          <?php if ($newsEducation_check-> num_rows > 0) {
            while($newsEducation_result = $newsEducation_check-> fetch_assoc()) { ?>
          <div class="col-lg-4">
            <div class="c_news text-center">
              <i class="<?= $newsEducation_result['icon']; ?>" aria-hidden="true"></i>
              <h2><?= $newsEducation_result['title']; ?></h2>
              <p>
                <?php 
                  $data = $newsEducation_result['description'];
                  if (strlen($data) > 150) {
                    echo substr($data, 0, 150) . "...." . "<br>";
                    echo "<a href='single.php?id=" . $newsEducation_result['id'] ." ' class='text-dark'>read more</a>";
                  }
                ?>
              </p>
            </div>
          </div>
          <?php }
          } else { ?>
          <div class="col-lg-4">
            <div class="c_news text-center">
              <h2>Data not found!</h2>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </section>
    <!-- education news end -->
<?php get_footer(); ?>