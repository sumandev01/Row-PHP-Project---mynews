<?php
// DB connection
include_once ("lib/admin-function.php");

// Data updated
if (isset($_POST['u_submit'])) {
    $id = intval($_POST['u_id']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $table_name = $_POST['table_name']; // কোন table update হবে

    // Secure table whitelist
    $allowed_tables = ['home_section1', 'home_section2', 'home_section3', 'home_section4'];

    if (in_array($table_name, $allowed_tables)) {
        $update_sql = "UPDATE $table_name SET title='$title', description='$description' WHERE id=$id";
        
        if ($conn->query($update_sql) === TRUE) {
            $_SESSION['success_message'] = $table_name;
            header("Location: home-page.php");
            exit;
        } else {
            echo "Update failed: " . $conn->error;
        }
    } else {
        echo "Invalid table name!";
    }
}

// Edit button Id find
if (isset($_GET['s1_id']) || isset($_GET['s2_id']) || isset($_GET['s3_id']) || isset($_GET['s4_id'])) {
    $final1 = null;
    $final2 = null;
    $final3 = null;
    $final4 = null;

    if (isset($_GET['s1_id'])) {
        $sec_id_1 = intval($_GET['s1_id']);
        $sec1_sql = "SELECT * FROM home_section1 WHERE id = $sec_id_1";
        $check_sql_1 = $conn->query($sec1_sql);

        if ($check_sql_1->num_rows > 0) {
            $final1 = $check_sql_1->fetch_assoc();
        }
    }

    if (isset($_GET['s2_id'])) {
        $sec_id_2 = intval($_GET['s2_id']);
        $sec2_sql = "SELECT * FROM home_section2 WHERE id = $sec_id_2";
        $check_sql_2 = $conn->query($sec2_sql);

        if ($check_sql_2->num_rows > 0) {
            $final2 = $check_sql_2->fetch_assoc();
        }
    }

    if (isset($_GET['s3_id'])) {
        $sec_id_3 = intval($_GET['s3_id']);
        $sec3_sql = "SELECT * FROM home_section3 WHERE id = $sec_id_3";
        $check_sql_3 = $conn-> query($sec3_sql);

        if ($check_sql_3-> num_rows > 0) {
            $final3 = $check_sql_3-> fetch_assoc();
        }
    }

    if (isset($_GET['s4_id'])) {
        $sec_id_4 = intval($_GET['s4_id']);
        $sec4_sql = "SELECT * FROM home_section4 WHERE id = $sec_id_4";
        $check_sql_4 = $conn-> query($sec4_sql);

        if ($check_sql_4-> num_rows > 0) {
            $final4 = $check_sql_4-> fetch_assoc();
        }
    }

    get_header();
    get_sidebar();
?>

<div class="card mb-4">
    <div class="card-body">
        <?php if (!empty($news_add_result)) { ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $news_add_result; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php } ?>

        <h3 class="mb-4">Edit Section Info</h3>

        <div class="row">
            <div class="col-lg-12">
                <?php if (!empty($final1)) { ?>
                    <!-- Form for home_section1 -->
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <input value="<?= $final1['id']; ?>" type="hidden" name="u_id" required>
                        <input value="home_section1" type="hidden" name="table_name">
                        
                        <div class="mb-3">
                            <label for="title1" class="form-label fw-bold">Title</label>
                            <input value="<?= $final1['title']; ?>" type="text" class="form-control" id="title1" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="description1" class="form-label fw-bold">Description</label>
                            <input value="<?= $final1['description']; ?>" type="text" class="form-control" id="description1" name="description" required>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>

                <?php if (!empty($final2)) { ?>
                    <!-- Form for home_section2 -->
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="mt-5">
                        <input value="<?= $final2['id']; ?>" type="hidden" name="u_id" required>
                        <input value="home_section2" type="hidden" name="table_name">
                        
                        <div class="mb-3">
                            <label for="title2" class="form-label fw-bold">Title</label>
                            <input value="<?= $final2['title']; ?>" type="text" class="form-control" id="title2" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="description2" class="form-label fw-bold">Description</label>
                            <input value="<?= $final2['description']; ?>" type="text" class="form-control" id="description2" name="description" required>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>

                <?php if (!empty($final3)) { ?>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="mt-5">
                        <input value="<?= $final3['id']; ?>" type="hidden" name="u_id" required>
                        <input value="home_section3" type="hidden" name="table_name">
                        
                        <div class="mb-3">
                            <label for="title2" class="form-label fw-bold">Title</label>
                            <input value="<?= $final3['title']; ?>" type="text" class="form-control" id="title2" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="description2" class="form-label fw-bold">Description</label>
                            <input value="<?= $final3['description']; ?>" type="text" class="form-control" id="description2" name="description" required>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>

                <?php if (!empty($final4)) { ?>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="mt-5">
                        <input value="<?= $final4['id']; ?>" type="hidden" name="u_id" required>
                        <input value="home_section4" type="hidden" name="table_name">
                        
                        <div class="mb-3">
                            <label for="title2" class="form-label fw-bold">Title</label>
                            <input value="<?= $final4['title']; ?>" type="text" class="form-control" id="title2" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="description2" class="form-label fw-bold">Description</label>
                            <input value="<?= $final4['description']; ?>" type="text" class="form-control" id="description2" name="description" required>
                        </div>

                        <button class="btn btn-dark" type="submit" name="u_submit">Update Now</button>
                    </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

</div>
</main> 

<?php
get_footer();

} else {
    header("Location:home-page.php");
    exit;
}
?>
