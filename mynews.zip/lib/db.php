<?php 
//db connection
$host = "localhost";
$user = "root";
$pass = "";
$db = "P541";

//create db connection
$conn = new mysqli($host, $user, $pass, $db);

//check connection
if( $conn-> connect_error){
	die($conn-> error);
}else{
	//echo "Database connection successfully";
}
?>