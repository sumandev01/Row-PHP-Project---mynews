<?php
//connection
    include_once ("lib/admin-function.php");

   if (isset($_POST['update'])) {
       $title = $_POST['title'];
       $description = htmlspecialchars($_POST['description']);

       $contact_sql = "UPDATE contact set title = '$title', description = '$description' ";

       if ($conn-> query($contact_sql)) {
           header("Location: contact-page.php?status=success");
       }else {
        die($conn-> error);
       }
   }

    // contact table query
    $contact_sql = "SELECT * FROM contact";
    $conn_contact = $conn-> query($contact_sql);

    if ($conn_contact-> num_rows > 0) {
        $contact_result = $conn_contact-> fetch_assoc();
    }

    get_header();
    get_sidebar();

?>      <div class="card mb-4">
            <div class="card-header">
                <h3 class="fw-bold">Edit contact page</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label fw-bold">Title</label>
                        <input value="<?= $contact_result['title']; ?>" type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label fw-bold">Description</label>
                        <textarea name="description" id="description" class="form-control" rows="7"><?= $contact_result['description']; ?></textarea>
                    </div>
                    <button type="submit" name="update" type="button" class="btn btn-dark">Update Now</button>
                </form>
            </div>
        </div>
    </div>
   </main>
<?php get_footer(); ?>