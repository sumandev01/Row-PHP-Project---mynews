<?php
//connection
    include_once ("lib/admin-function.php");

    $message = "";

    // about table query
    $about_sql = "SELECT * FROM about";
    $conn_about = $conn-> query($about_sql);
    if ($conn_about-> num_rows > 0) {
        $about_final = $conn_about-> fetch_assoc();
    }

    get_header();
    get_sidebar();

?>  <div class="update-message mb-4">
        <p class="text-success"><?= $message; ?></p>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="fw-bold">About page info</h3>
        </div>
        <div class="card-body">
            <h5 class="mt-4 d-block fw-bold">Title:</h5><hr>
            <h1><?= $about_final['title']; ?></h1>
            <h5 class="mt-4 d-block fw-bold">Description:</h5><hr>
            <p><?= nl2br(html_entity_decode($about_final['description']));  ?></p>
            <a href="edit-about-page.php">Edit</a>
        </div>
    </div>
    </div>
   </main>
<?php get_footer(); ?>