<?php
    //connection
    include_once ("lib/admin-function.php");

    $message = "";

    // FAQ table query
    $faq_sql = "SELECT * FROM faq";
    $faq_check = $conn-> query($faq_sql);

    get_header();
    get_sidebar();

?>  <div class="update-message mb-4">
        <p class="text-success"><?= $message; ?></p>
    </div>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="fw-bold">FAQ page info</h3>
            <a class="nav-link" href="add-faq-page.php">Add now</a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="w-100">
                <thead class="table-light">
                    <tr>
                        <th width="5%">SL</th>
                        <th>FAQ</th>
                        <th>ANS</th>
                        <th width="15%">Edit/Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $count = 0;
                        if ($faq_check-> num_rows > 0) {
                            while($faq_result = $faq_check-> fetch_assoc()){
                                $count++; // Auto number count
                    ?>
                    <tr>
                        <td><?= $count; ?></td>
                        <td><?= $faq_result['faq']; ?></td>
                        <td><?= $faq_result['ans'] ?></td>
                        <td>
                            <a href="edit-faq-page.php?id=<?= $faq_result['id']; ?>">Edit</a>
                            <span>/</span>
                            <a href="delete.php?del-faq=<?= $faq_result['id']; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php }
                        }else { ?>
                        <tr>
                            <td colspan="4">Data not found</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
   </main>
<?php get_footer(); ?>