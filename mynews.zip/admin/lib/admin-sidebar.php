<?php 
    $titles = getPageTitles();
    $pageTitle = end($titles);

    $current_page = basename($_SERVER['PHP_SELF']);
?>
<div id="layoutSidenav">
	  <div id="layoutSidenav_nav">
	    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
	      <div class="sb-sidenav-menu">
	        <div class="nav">
	          <div class="sb-sidenav-menu-heading">Core</div>
	          <a class="nav-link <?= ($current_page == 'admin.php') ? 'active' : '' ?>" href="admin.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
	            Dashboard
	          </a>
	          <a class="nav-link" href="../index.php" target="_blank">
	            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
	            Website
	          </a>
	          <div class="sb-sidenav-menu-heading">Pages</div>
	          <a class="nav-link <?= ($current_page == 'home-page.php') ? 'active' : '' ?>" href="home-page.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
	            Home Page
	          </a>
	          <a class="nav-link <?= ($current_page == 'about-page.php') ? 'active' : '' ?>" href="about-page.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
	            About Page
	          </a>
	          <a class="nav-link <?= ($current_page == 'contact-page.php') ? 'active' : '' ?>" href="contact-page.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-envelope"></i></div>
	            Contact Page
	          </a>
	          <a class="nav-link <?= ($current_page == 'faq-page.php') ? 'active' : '' ?>" href="faq-page.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-question-circle"></i></div>
	            FAQ Page
	          </a>
	          <a class="nav-link <?= ($current_page == 'banner.php') ? 'active' : '' ?>" href="banner.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-image"></i></div>
	            Banner
	          </a>
	          <a class="nav-link <?= ($current_page == 'category.php') ? 'active' : '' ?>" href="category.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-list-alt"></i></div>
	            Category
	          </a>
	          <a class="nav-link <?= ($current_page == 'news.php') ? 'active' : '' ?>" href="news.php">
	            <div class="sb-nav-link-icon"><i class="fas fa-newspaper"></i></div>
	            News
	          </a>
	          <a class="nav-link <?= ($current_page == 'footer.php') ? 'active' : '' ?>" href="footer.php">
	            <div class="sb-nav-link-icon"><i class="fa-solid fa-pager"></i></div>
	            Footer
	          </a>
	        </div>
	      </div>
	      <div class="sb-sidenav-footer">
	        <div class="small">Logged in as:</div>
	        <?= $_SESSION['name']; ?>
	      </div>
	    </nav>
	  </div>
	  <div id="layoutSidenav_content">
	    <main>
	      <div class="container-fluid px-4">
	        <h1 class="mt-4">Dashboard</h1>
	        <ol class="breadcrumb mb-4">
                <?php foreach ($titles as $key => $title): ?>
	          <li class="breadcrumb-item <?= ($key === array_key_last($titles)) ? 'active' : '' ?>"><?= $title ?></li>
              <?php endforeach ?>
	        </ol>


