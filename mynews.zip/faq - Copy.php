<?php 
include_once("function/function.php");

    // FAQ table query
$faq_sql = "SELECT * FROM faq";
$conn_faq = $conn->query($faq_sql);

get_header();
?>
<!-- FAQ Section -->
<section class="py-5 bg-light">
 <div class="container">
  <h2 class="fw-bold mb-4 text-center">Frequently Asked Questions</h2>
  <div class="row justify-content-center">
   <div class="col-md-8">
    <div class="accordion" id="faqAccordion">
     <?php 
     if ($conn_faq->num_rows > 0) {
      $index = 0;
      while($final = $conn_faq->fetch_assoc()) {
       $faqId = "faq" . $index;
       $headingId = "heading" . $index;
       $isFirst = $index === 0;
       ?>
       <div class="accordion-item">
        <h2 class="accordion-header" id="<?= $headingId ?>">
         <button class="accordion-button <?= $isFirst ? '' : 'collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $faqId ?>" aria-expanded="<?= $isFirst ? 'true' : 'false' ?>" aria-controls="<?= $faqId ?>">
          <?= htmlspecialchars($final['faq']) ?>
         </button>
        </h2>
        <div id="<?= $faqId ?>" class="accordion-collapse collapse <?= $isFirst ? 'show' : '' ?>" aria-labelledby="<?= $headingId ?>" data-bs-parent="#faqAccordion">
         <div class="accordion-body">
          <?= htmlspecialchars($final['ans']) ?>
         </div>
        </div>
       </div>
       <?php 
       $index++;
      }
     } else {
      ?>
      <div class="accordion-item">
       <h2 class="accordion-header" id="noDataHeading">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#noData" aria-expanded="false" aria-controls="noData">
         Data not found
        </button>
       </h2>
       <div id="noData" class="accordion-collapse collapse" aria-labelledby="noDataHeading" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
         Data not found
        </div>
       </div>
      </div>
     <?php } ?>
    </div>
   </div>
  </div>
 </div>
</section>
<?php get_footer(); ?>
